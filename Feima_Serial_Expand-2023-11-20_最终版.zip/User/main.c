#include "stm32f4xx.h"
#include "./usart/bsp_debug_usart.h"
#include "./led/bsp_led.h"
/**
  * @brief  ������
  * @param  ��
  * @retval ��
  */


extern unsigned char get_usart2RxFlag;
extern unsigned char get_usart2ReceiveBuff[255];


extern unsigned char get_usart3RxFlag;
extern unsigned char get_usart3ReceiveBuff[255];
extern unsigned char RX_SPRUCE_COUNT;
extern unsigned char RX_SPRUCE_BUFF[1024];

extern unsigned char get_usart1RxFlag;
extern unsigned char get_usart1ReceiveBuff[255];

extern unsigned char get_usart4RxFlag;
extern unsigned char get_usart4ReceiveBuff[255];


int main(void)
{

  /* Ƕ�������жϿ�������ѡ�� */
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
  LED_GPIO_Config();
  /*��ʼ��USART ����ģʽΪ 115200 8-N-1���жϽ���*/
  Debug_USART1_Config();
  Debug_USART2_Config();
  Debug_USART3_Config();
  Debug_USART4_Config();



  while(1)
    {
      if(get_usart1RxFlag==1)
        {
          get_usart1RxFlag=0;
          unsigned char CRC_GRAPHICS_BOADR=0x00;
          int i=0;
          for(i = 0; i < (get_usart1ReceiveBuff[2] - 2); i++)
            {
              CRC_GRAPHICS_BOADR += get_usart1ReceiveBuff[i];
            }
          if(get_usart1ReceiveBuff[get_usart1ReceiveBuff[2] - 2] == CRC_GRAPHICS_BOADR)
            {
              GPIO_ToggleBits(GPIOE, GPIO_Pin_7);

              for( i = 0; i < (get_usart1ReceiveBuff[2]); i++)
                {
                  USART_SendData(USART2,get_usart1ReceiveBuff[i]);
                  while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
                }
            }
        }

      if(get_usart2RxFlag==1)
        {
          get_usart2RxFlag=0;
          unsigned char CRC_SPRUCE=0x00;
          int i=0;
          for( i=0; i<(get_usart2ReceiveBuff[2]-2); i++)
            {
              CRC_SPRUCE+=get_usart2ReceiveBuff[i];
            }
          if(get_usart2ReceiveBuff[get_usart2ReceiveBuff[2]-2]==CRC_SPRUCE)
            {

              switch(get_usart2ReceiveBuff[4])
                {
                case 0x21:
                {
                  for( i=0; i<get_usart2ReceiveBuff[2]; i++)
                    {
                      USART_SendData(UART4, get_usart2ReceiveBuff[i]);
                      while(USART_GetFlagStatus(UART4, USART_FLAG_TXE) == RESET);
                    }
                };
                break;
                case 0x20:
                {
                  CRC_SPRUCE=0x00;
                  unsigned char SPRUCE_Buffer[127]= {0},crc=0x00,t=0;
                  SPRUCE_Buffer[0]=0xAA;
                  int j=1;
                  for ( i=5; i<get_usart2ReceiveBuff[2]-2; i++)
                    {
                      SPRUCE_Buffer[j]=get_usart2ReceiveBuff[i];
                      j++;
                    }
                  unsigned char len=SPRUCE_Buffer[1]-1;
                  while(len--)
                    {
                      crc ^= SPRUCE_Buffer[t++];

                      for(unsigned char k = 8; k > 0; --k)
                        {
                          if(crc & 0x80)
                            {
                              crc = (crc << 1) ^ 0xD5;
                            }
                          else
                            {
                              crc = (crc << 1);
                            }
                        }
                    }
                  SPRUCE_Buffer[j] = crc;
                  for( i = 0; i < SPRUCE_Buffer[1]; i++)
                    {
                      USART_SendData(USART3,SPRUCE_Buffer[i]);
                      while(USART_GetFlagStatus(USART3,USART_FLAG_TXE)==RESET);
                    }
                };
                break;
                case 0x22:
                {
                  for( i=0; i<get_usart2ReceiveBuff[2]; i++)
                    {
                      USART_SendData(USART1,get_usart2ReceiveBuff[i]);
                      while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
                    }
                };
                break;
                }
            }

        }
      if(get_usart3RxFlag==1)
        {
          get_usart3RxFlag=0;
          RX_SPRUCE_BUFF[0] = 0xA9;
          RX_SPRUCE_BUFF[1] = 0x9A;
          RX_SPRUCE_BUFF[2] = 0x05 + get_usart3ReceiveBuff[1];
          RX_SPRUCE_BUFF[3] = RX_SPRUCE_COUNT++;
          RX_SPRUCE_BUFF[4] = 0x20;
          int j = 5;
          int k = 0;
          for( k = 1; k < get_usart3ReceiveBuff[1] - 1; k++)
            {
              RX_SPRUCE_BUFF[j] = get_usart3ReceiveBuff[k];
              j++;
            }

          RX_SPRUCE_BUFF[j] = 0x00;

          for( k = 0; k < RX_SPRUCE_BUFF[2] - 2; k++)
            {
              RX_SPRUCE_BUFF[j] += RX_SPRUCE_BUFF[k];
            }

          RX_SPRUCE_BUFF[j + 1] = 0xAA;

          for( k = 0; k < RX_SPRUCE_BUFF[2]; k++)
            {
              USART_SendData(USART2, RX_SPRUCE_BUFF[k]);
              while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
            }
        }
      if(get_usart4RxFlag==1)
        {
          get_usart4RxFlag=0;
          unsigned char CRC_SPRUCE=0x00;
          for(int i=0; i<(get_usart4ReceiveBuff[2]-2); i++)
            {
              CRC_SPRUCE+=get_usart4ReceiveBuff[i];
            }
          if(get_usart4ReceiveBuff[get_usart4ReceiveBuff[2]-2]==CRC_SPRUCE)
            {
              for(int i=0; i<get_usart4ReceiveBuff[2]; i++)
                {
                  USART_SendData(USART2, get_usart4ReceiveBuff[i]);
                  while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
                }
              GPIO_ToggleBits(GPIOE,GPIO_Pin_7);
            }
        }
    }
}



/*********************************************END OF FILE**********************/

